
public class Pizza {

    // ***Datos del pedido ***
    String nombre; 

    
    String[] ingredientes = new String[3];

    
    Pizza siguiente;


    public Pizza(String nombre, String[] ingredientes) {
        this.nombre    = nombre;
        this.siguiente = null; // sin vecino debajo todavía

         
        for (int i = 0; i < 3; i++) {
            this.ingredientes[i] = ingredientes[i];
        }
    }


    @Override
    public String toString() {
        
        String lista = "";
        for (int i = 0; i < 3; i++) {
            lista += ingredientes[i];
            if (i < 2) lista += ", ";
        }

        return "[Pizza: " + nombre + " | Ingredientes: " + lista + "]";
    }
}
